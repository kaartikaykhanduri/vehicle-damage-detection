# CarDamagedetection
This model detects the amount of damage of a car and and the area where the damage is present using computervision , tensorflow , and etc libraries of python .
